/**
 * Project #2
 * @author Linh
 * CS 2334, Section 010, Lab Section 013
 * Jan 12, 2016
 * <P>
 * Driver class: This class contains the main method for running the program.
 * </P>
 * @version 1.0
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Driver {
	public ArrayList<Movie> movieCollection = new ArrayList<Movie>();
	public ArrayList<Series> seriesCollection = new ArrayList<Series>();
	public ArrayList<Object> bothCollections = new ArrayList<Object>();
	private String input = "";
	/**
	 * This method goes and searches through collection and then prints out results
	 * to the user. 
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall search through the ArrayList and print out the movies 
	 * that matches the user's input.
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public void searchMovie(ArrayList<Movie> movieCollection) throws IOException, ClassNotFoundException
	{
		BufferedReader inputReader = new BufferedReader
				(new InputStreamReader( System.in ) );
				System.out.print( "Type in the movie file: " );
				String movieFilename = inputReader.readLine();
				Movie.readFile(movieFilename);
	}
	
	/**
	 * This method goes and searches through collection and then prints out results
	 * to the user.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall search through the ArrayList and print out the series 
	 * that matches the user's input.
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public void searchSeries(ArrayList<Series> seriesCollection) throws IOException, ClassNotFoundException
	{
		BufferedReader inputReader = new BufferedReader
				(new InputStreamReader( System.in ) );
				System.out.print( "Type in the movie file: " );
				String seriesFilename = inputReader.readLine();
				Series.readFile(seriesFilename);
	}
	
	/**
	 * Sorts the movies by title.
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the movies by title.
	 */
	public void sortMovieTitle(ArrayList<Movie> movieCollection)
	{
		
	}
	
	/**
	 * Sorts the series by title.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the series by title.
	 */
	public void sortSeriesTitle(ArrayList<Series> seriesCollection)
	{
		
	}
	
	/**
	 * Sorts the movies by year.
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the movies by year.
	 */
	public void sortMovieYear(ArrayList<Movie> movieCollection)
	{
		
	}
	
	/**
	 * Sorts the series by year.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the series by year.
	 */
	public void sortSeriesYear(ArrayList<Series> seriesCollection)
	{
		
	}
	//remember to edit this save method somewhat because this is not the file
	//for the 
	/**
	 * Saves the data if the user wishes to after it is displayed to the user.
	 * @param bothCollections
	 * <dd>PRE - There must be an arrayList of both collection objects available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList of objects
	 * and save the data in a file with the given name in the same format it was
	 * displayed to the user.
	 * @throws IOException 
	 */
	public void save(ArrayList<Object> bothCollections) throws IOException
	{
		FileWriter outfile = new FileWriter("output.txt");
		BufferedWriter bw = new BufferedWriter(outfile);
		bw.write("This is a test -- did it work?");
		bw.newLine();
		bw.close();

	}

	public static void main(String[] args) {
		
	}

}
