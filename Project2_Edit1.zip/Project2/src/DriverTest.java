import static org.junit.Assert.*;

import org.junit.Test;

public class DriverTest {

	@Test
	public void testSortMovieTitle() {
		//make new ArrayList of Movie objects and then use
		//AssertEquals to test out the method
	}

	@Test
	public void testSortSeriesTitle() {
		//make new ArrayList of Series objects and then use
		//AssertEquals to test out the method
	}

	@Test
	public void testSortMovieYear() {
		//make new ArrayList of Movie objects and then use
		//AssertEquals to test out the method
	}

	@Test
	public void testSortSeriesYear() {
		//make new ArrayList of Series objects and then use
		//AssertEquals to test out the method
	}

}
