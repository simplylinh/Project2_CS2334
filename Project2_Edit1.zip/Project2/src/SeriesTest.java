import static org.junit.Assert.*;

import org.junit.Test;

public class SeriesTest {

	@Test
	public void testReadFile() {
		//send in a file
		//create the String array to test the reading and storing of file
		//AssertEquals to test out the method
	}

	@Test
	public void testParseSeries() {
		//create new String array to parse test
		//AssertEquals to test out the method
	}

	@Test
	public void testCompareTo() {
		//create new Series object to compare
		//AssertEquals to test out the method
	}

}
