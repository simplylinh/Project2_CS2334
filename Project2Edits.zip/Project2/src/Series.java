/**
 * Project #2
 * @author Linh
 * CS 2334, Section 010, Lab Section 013
 * Feb 19, 2016
 * <P>
 * Series class: This class contains all the information about the Broadcast series
 * and contains the methods to read the file in, parse the information from the String
 * array, and the method to compare the two Series objects' titles. There is 
 * also a subclass SeriesYearComparator in here.
 * </P>
 * @version 1.0
 */
import java.util.Arrays;
import java.io.FileNotFoundException;
import java.util.Comparator;

public class Series implements Comparable<Series>{
	private String seriesTitle = "";
	private String seriesYr = "";
	private String epYr = "";
	private String epTitle = "";
	private String seasonNum = "";
	private String epNum = "";
	private String[] seriesInfo = new String[100]; 
	
	/**
	 * @param seriesTitle
	 * @param seriesYr
	 * Constructor for the Series class. This constructor has only these two
	 * basic options of series title and year.
	 */
	public Series(String seriesTitle, String seriesYr)
	{
		
	}
	
	/**
	 * @param seriesTitle
	 * @param seriesYr
	 * @param epYear
	 * @param epTitle
	 * @param seasonNum
	 * @param epNum
	 * Constructor for the Series class. This constructor has the options of
	 * the series title, year, and other specific details on the episodes.
	 */
	public Series(String seriesTitle, String seriesYr, String epYr, String epTitle,
			String seasonNum, String epNum)
	{
		
	}
	
	/**
	 * This method returns the series title.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the series title of the series.
	 */
	public String getSeriesTitle(){
		return seriesTitle;
	}
	
	/**
	 * This method returns the series year.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the series year of the series.
	 */
	public String getStartingYear(){
		return seriesYr;
	}
	
	/**
	 * This method returns the release year.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the release year of the series.
	 */
	public String getEpReleaseYear(){
		return epYr;
	}
	
	/**
	 * This method returns the episode title.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the episode title of the series.
	 */
	public String getEpTitle(){
		return epTitle;
	}
	
	/**
	 * This method returns the season number.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the season number of the series.
	 */
	public String getSeasonNum(){
		return seasonNum;
	}
	
	/**
	 * This method returns the episode number.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the episode number of the series.
	 */
	public String getEpNum(){
		return epNum;
	}
	
	/**
	 * This method asks the file from the reader and reads the file into the program.
	 * It will store it into the string as well.
	 * @param 
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives String seriesFileName to store the file in
	 * <dd>POST - Reads in the file given by the user and stores into
	 *  seriesFileName
	 */
	public void readFile(String seriesFileName) throws FileNotFoundException
	{
		
	}
	
	/**
	 * This method takes a line one by one from the array, and parses the information
	 * to put it into the proper category where it belongs.
	 * @param seriesInfo - This an array of Strings that contains all of the information
	 * about the movies but they are not split/parsed yet
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - There must be an array of the series' information in order to parse
	 * or split the data.
	 * <dd>POST - Using the array, it will go through the lines of code individually and
	 * see that which information falls into which section.
	 */
	public void parseSeries(String[] seriesInfo)
	{
		
	}
	
	/**
	 * This method from the comparable interface will compare the Movie objects'
	 * titles and see if there is a match
	 * @param series - This is the movie object that this method will use to compare
	 * @return int
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives series object to compare
	 * <dd>POST - Returns an integer number to say if the titles matched or not
	 */
	public int compareTo(Series series)
	{
		int num = 0;
		return num;
	}
	
	/**
	 * This is the Comparator subclass within the Series class which will be used
	 * to override the compareTo method when the user wants to compare the series
	 * by year.
	 */
	public static final Comparator<Series> SERIESYEAR_COMPARATOR 
	= new Comparator<Series>() {
		public int compare(Series series1, Series series2) 
		{
			int num = 0;
			return num;
		}
	};

}
