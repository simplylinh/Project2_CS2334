/**
 * Project #2
 * @author Linh
 * CS 2334, Section 010, Lab Section 013
 * Jan 12, 2016
 * <P>
 * Driver class: This class contains the main method for running the program.
 * </P>
 * @version 1.0
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.xml.ws.Response;

import java.io.IOException;

public class Driver{
	
	public ArrayList<Movie> movieCollection = new ArrayList<Movie>();
	public ArrayList<Series> seriesCollection = new ArrayList<Series>();
	public ArrayList<Object> bothCollections = new ArrayList<Object>();
	//private String input = "";
	private String moviefilename = "";
	private String seriesfilename = "";
	
	/**
	 * This method goes and searches through collection and then prints out results
	 * to the user. 
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall search through the ArrayList and print out the movies 
	 * that matches the user's input.
	 */
	public void searchMovie(ArrayList<Movie> movieCollection) throws IOException
	{
		BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
				System.out.print( "Enter movie file to be read: " );
				String moviefilename = inputReader.readLine();
				
	}
	
	/**
	 * This method goes and searches through collection and then prints out results
	 * to the user.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall search through the ArrayList and print out the series 
	 * that matches the user's input.
	 */
	public void searchSeries(ArrayList<Series> seriesCollection) throws IOException
	{
		BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
		System.out.print( "Enter series file to be read: " );
		String seriesfilename = inputReader.readLine();
	}
	
	/**
	 * Sorts the movies by title.
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the movies by title.
	 */
	public void sortMovieTitle(ArrayList<Movie> movieCollection)
	{
		
	}
	
	/**
	 * Sorts the series by title.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the series by title.
	 */
	public void sortSeriesTitle(ArrayList<Series> seriesCollection)
	{
		
	}
	
	/**
	 * Sorts the movies by year.
	 * @param movieCollection
	 * <dd>PRE - There must be an arrayList of movies available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the movies by year.
	 */
	public void sortMovieYear(ArrayList<Movie> movieCollection)
	{
		
	}
	
	/**
	 * Sorts the series by year.
	 * @param seriesCollection
	 * <dd>PRE - There must be an arrayList of series available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList and sort the series by year.
	 */
	public void sortSeriesYear(ArrayList<Series> seriesCollection)
	{
		
	}
	
	/**
	 * Saves the data if the user wishes to after it is displayed to the user.
	 * @param bothCollections
	 * <dd>PRE - There must be an arrayList of both collection objects available 
	 * and sent to this method as a parameter.
	 * <dd>POST - It shall go through the arrayList of objects
	 * and save the data in a file with the given name in the same format it was
	 * displayed to the user.
	 */
	public void save(ArrayList<Object> bothCollections) throws IOException
	{
		FileWriter outfile = new FileWriter("MediaDatabaseSearch.txt");
		BufferedWriter bw = new BufferedWriter(outfile);
		// TODO edit the line of code below to print the user's search to the MediaDatabaseSearch.txt file
		bw.write("This is a test -- did it work?");
		bw.newLine();
		bw.close();
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));
		String ynsearch2 = "y";
		while(ynsearch2 == "y"){
			String msbsearch = "a";
			//First Question while loop below
			while(msbsearch != "m" || msbsearch != "s" || msbsearch != "b"){
			System.out.println("Search (m)ovies, (s)eries, or (b)oth?");
			String msbsearch = inputReader.readLine();
			if(msbsearch == "m" || msbsearch == "s" || msbsearch == "b"){
				if(msbsearch == "m"){
					String dataType1 = "MOVIES";
				}
				if(msbsearch == "s"){
					String dataType2 = "TV SERIES";
				}
				if(msbsearch == "b"){
					String dataType3 = "MOVIES & TV SERIES";
				}
				String tybsearch = "a";
				//Second question while loop below
				while(tybsearch != "t" || tybsearch != "y" || tybsearch != "b"){
				System.out.println("Search (t)itle, (y)ear, or (b)oth?");
				String tybsearch = inputReader.readLine();
				if(tybsearch == "t" || tybsearch == "b"){
					String epsearch = "a";
					//exact or partial matches while loop below 
					while(epsearch != "e" || epsearch != "p"){
					System.out.println("Search for (e)xact or (p)artial matches?");
					String epsearch = inputReader.readLine();
					if(epsearch == "e"){
						//TODO complete if statement body
					}//end of if statement for epsearch = e
					else if(epsearch == "p"){
						//TODO complete else if statement body
					}//end of else if statement for epsearch == p
					else{
						System.out.println("Invalid response. \n Please enter 'e' for exact matches or 'p' for partial matches: ");
					}//end of else statement for epsearch
					}//end of while loop for epsearch
					//Getting the title from the user
					System.out.println("Title?");
					String usertitle = inputReader.readLine();
				}//end of if statement for tybsearch
				else if(tybsearch == "y" || tybsearch == "b"){
					//TODO complete else if statement body
					System.out.println("Year(s)?");
					String useryear = inputReader.readLine();
				}//end of else if statement for tybsearch 
				else{
					System.out.println("Invalid response. \n Please enter 't' for title, 'y' for year, or 'b' for both: ");
				}//end of else statement for tybsearch
				}//end of while loop for tybsearch

				if((msbsearch == "s" || msbsearch == "b") && (tybsearch == "t" || tybsearch == "b")){
					String ynsearch = "y";
					while(ynsearch == "y"){
					System.out.println("Include episode titles in search and output (y/n)?");
					String ynsearch = inputReader.readLine();
					if(ynsearch == "y"){
						//TODO complete body
						String dataType4 = "TV EPISODES";
					}//end of if statement for ynsearch = y
					else if(ynsearch == "n"){
						//TODO complete body
					}//end of else if statement for ynsearch = n
					else{
						System.out.println("Invalid response. \n Please enter 'y' for yes or 'n' for no: ");
					}
				}//end of while loop for ynsearch 
				}//end of if statement for episode titles ynsearch 
			}//end of if statement for msbsearch = m, msbsearch = s, or msbsearch = b
			else{
				System.out.println("Invalid response. \n Please enter 'm' for movies, 's' for series, or 'b' for both: ");
			}//end of else statement for msbsearch
			}//end of while loop for msbsearch
			String tysearch = "a";
			while(tysearch != "t" || tysearch != "y"){
				System.out.println("Sort by (t)itle or (y)ear?");
				String tysearch = inputReader.readLine();
				if(tysearch == "t"){
					//TODO complete body
				}
				else if(tysearch == "y"){
					//TODO complete body
				}
				else{
					System.out.println("Invalid response. \n Please enter 't' for title or 'y' for year: ");
				}
			}//end of while loop for tysearch
			String ynsearch2 = "a";
			while(ynsearch2 != "y" || ynsearch2 != "n"){
				System.out.println("Continue (y/n)?");
				String ynsearch2 = inputReader.readLine();
				if(ynsearch2 == "n"){
					System.out.println("Thank you for using MDb. Goodbye.");
					System.exit(0);
				}
				else if(ynsearch2 != "y" || ynsearch2 != "n"){
					System.out.println("Invalid response. \n Please enter 'y' for yes or 'n' for no: ");
				}
				else{
					System.out.println("New Search");
				}
			}//end of while loop for ynsearch2 valid/invalid response
			//TODO fix output to user
			if(msbsearch == "m"){
				System.out.println("SEARCHED MOVIES");
				}
			if(msbsearch == "s" && ynsearch == "n"){
				System.out.println("SEARCHED TV SERIES");
			}
			if(msbsearch == "b"){
				System.out.println("SEARCHED MOVIES & TV SERIES");
			}
		}//end of while loop for ynsearch2 continue question

		
	}//end of main method

}//end of Driver class
