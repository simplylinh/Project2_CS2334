/**
 * Project #2
 * @author Linh
 * CS 2334, Section 010, Lab Section 013
 * Feb 19, 2016
 * <P>
 * Movie class: This class contains all the information about the movie and 
 * also has the method for parsing the array of Strings itself along with methods
 * for reading the file and comparing the Movie objects. There is another subclass
 * within this class called MovieYearComparator.
 * </P>
 * @version 1.0
 */

import java.util.Arrays;
import java.util.Comparator;

public class Movie implements Comparable<Movie> {
	private String[] movieInfo;
	private String title;
	private String year;
	private String romanNum;
	private String type;
	
	/**
	 * @param title
	 * @param type
	 * @param romanNum
	 * @param year
	 * Constructor for the Movie class. This constructor has the option of including the type
	 * of movie such as TV or video. 
	 */
	public Movie(String title, String type, String romanNum, String year )
	{
		
	}
	
	/**
	 * Constructor for the Movie class. This constructor doesn't
	 * have the option of including the type of movie such as TV or video.
	 * @param title
	 * @param romanNum
	 * @param year
	 */
	public Movie(String title, String romanNum, String year)
	{
		
	}
	
	/**
	 * This method returns the title
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the title of the movie.
	 */
	public String getTitle(){
		return title;
	}
	
	/**
	 * This method returns the movie year.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the year of the movie.
	 */
	public String getYear(){
		return year;
	}
	
	/**
	 * This method returns the Roman numeral.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the Roman numeral of the movie.
	 */
	public String getRomanNum(){
		return romanNum;
	}
	
	/**
	 * This method returns the movie type.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the type (video/TV) of the movie.
	 */

	public String getType(){
		return type;
	}
	
	/**
	 * This method asks the file from the reader and reads the file into the program.
	 * It will store it into the string as well.
	 * @param 
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives String movieFileName to store the file in
	 * <dd>POST - Reads in the file given by the user and stores into
	 *  movieFileName
	 */
	public void readFile(String movieFileName){
		
	}
	
	/**
	 * This method takes a line one by one from the array, and parses the information
	 * to put it into the proper category where it belongs.
	 * @param movieInfo - This an array of Strings that contains all of the information
	 * about the movies but they are not split/parsed yet
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - There must be an array of the movies' information in order to parse
	 * or split the data.
	 * <dd>POST - Using the array, it will go through the lines of code individually and
	 * see that which information falls into which section.
	 */
	public void parseMovie(String[] movieInfo)
	{
		
	}
	
	/**
	 * This method from the comparable interface will compare the Movie objects'
	 * titles and see if there is a match
	 * @param movie - This is the movie object that this method will use to compare
	 * @return int
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives Movie object to compare
	 * <dd>POST - Returns an integer number to say if the titles matched or not
	 */
	public int compareTo(Movie movie)
	{
		int num = 0;
		return num; //placeholder for now
	}
	
	/**
	 * This is the Comparator subclass within the Movie class which will be used
	 * to override the compareTo method when the user wants to compare the movie
	 * by year.
	 */
	public static final Comparator<Movie> MOVIEYEAR_COMPARATOR 
	= new Comparator<Movie>() {
		public int compare(Movie movie1, Movie movie2) 
		{
			int num = 0;
			return num;
		}
	};
}
